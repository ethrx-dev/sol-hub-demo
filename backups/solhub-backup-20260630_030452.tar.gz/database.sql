--
-- PostgreSQL database dump
--

\restrict DNdXZQUsJootsEgskaHbS6WWKeAjevSuXTWl9GttarajKnh5WBsPZmgXJTbbYHB

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.verification_tokens DROP CONSTRAINT IF EXISTS verification_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.resources DROP CONSTRAINT IF EXISTS resources_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reports DROP CONSTRAINT IF EXISTS reports_reporter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_innovator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.profiles DROP CONSTRAINT IF EXISTS profiles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pillar_submissions DROP CONSTRAINT IF EXISTS pillar_submissions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.milestones DROP CONSTRAINT IF EXISTS milestones_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS matches_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS matches_mentor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS matches_investor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_post_id_fkey;
ALTER TABLE IF EXISTS ONLY public.investments DROP CONSTRAINT IF EXISTS investments_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.investments DROP CONSTRAINT IF EXISTS investments_investor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_creator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_messages DROP CONSTRAINT IF EXISTS group_messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_messages DROP CONSTRAINT IF EXISTS group_messages_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_members DROP CONSTRAINT IF EXISTS group_members_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_members DROP CONSTRAINT IF EXISTS group_members_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.forum_threads DROP CONSTRAINT IF EXISTS forum_threads_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.forum_threads DROP CONSTRAINT IF EXISTS forum_threads_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.forum_replies DROP CONSTRAINT IF EXISTS forum_replies_thread_id_fkey;
ALTER TABLE IF EXISTS ONLY public.forum_replies DROP CONSTRAINT IF EXISTS forum_replies_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_organizer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_attendees DROP CONSTRAINT IF EXISTS event_attendees_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_attendees DROP CONSTRAINT IF EXISTS event_attendees_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_uploader_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.doc_library_items DROP CONSTRAINT IF EXISTS doc_library_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.doc_library_items DROP CONSTRAINT IF EXISTS doc_library_items_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.connections DROP CONSTRAINT IF EXISTS connections_following_id_fkey;
ALTER TABLE IF EXISTS ONLY public.connections DROP CONSTRAINT IF EXISTS connections_follower_id_fkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_post_id_fkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_posts DROP CONSTRAINT IF EXISTS blog_posts_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_posts DROP CONSTRAINT IF EXISTS blog_posts_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_blocker_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_blocked_id_fkey;
ALTER TABLE IF EXISTS ONLY public.albums DROP CONSTRAINT IF EXISTS albums_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.album_media DROP CONSTRAINT IF EXISTS album_media_album_id_fkey;
ALTER TABLE IF EXISTS ONLY public.activity_logs DROP CONSTRAINT IF EXISTS activity_logs_user_id_fkey;
DROP INDEX IF EXISTS public.ix_webhook_events_event_id;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_reports_status;
DROP INDEX IF EXISTS public.ix_reports_reporter_id;
DROP INDEX IF EXISTS public.ix_pillar_submissions_pillar;
DROP INDEX IF EXISTS public.ix_forum_categories_slug;
DROP INDEX IF EXISTS public.ix_doc_categories_slug;
DROP INDEX IF EXISTS public.ix_blog_posts_slug;
DROP INDEX IF EXISTS public.ix_blog_categories_slug;
DROP INDEX IF EXISTS public.ix_blocks_blocker_id;
DROP INDEX IF EXISTS public.ix_blocks_blocked_id;
DROP INDEX IF EXISTS public.ix_activity_logs_user_id;
DROP INDEX IF EXISTS public.ix_activity_logs_created_at;
DROP INDEX IF EXISTS public.ix_activity_logs_activity_type;
ALTER TABLE IF EXISTS ONLY public.webhook_events DROP CONSTRAINT IF EXISTS webhook_events_pkey;
ALTER TABLE IF EXISTS ONLY public.verification_tokens DROP CONSTRAINT IF EXISTS verification_tokens_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.verification_tokens DROP CONSTRAINT IF EXISTS verification_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS uq_user_post_like;
ALTER TABLE IF EXISTS ONLY public.group_members DROP CONSTRAINT IF EXISTS uq_group_user;
ALTER TABLE IF EXISTS ONLY public.connections DROP CONSTRAINT IF EXISTS uq_follower_following;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_user_id_key;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.resources DROP CONSTRAINT IF EXISTS resources_pkey;
ALTER TABLE IF EXISTS ONLY public.reports DROP CONSTRAINT IF EXISTS reports_pkey;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.profiles DROP CONSTRAINT IF EXISTS profiles_user_id_key;
ALTER TABLE IF EXISTS ONLY public.profiles DROP CONSTRAINT IF EXISTS profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_pkey;
ALTER TABLE IF EXISTS ONLY public.pillar_submissions DROP CONSTRAINT IF EXISTS pillar_submissions_pkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_user_id_key;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.milestones DROP CONSTRAINT IF EXISTS milestones_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS matches_pkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_pkey;
ALTER TABLE IF EXISTS ONLY public.investments DROP CONSTRAINT IF EXISTS investments_pkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_pkey;
ALTER TABLE IF EXISTS ONLY public.group_messages DROP CONSTRAINT IF EXISTS group_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.group_members DROP CONSTRAINT IF EXISTS group_members_pkey;
ALTER TABLE IF EXISTS ONLY public.forum_threads DROP CONSTRAINT IF EXISTS forum_threads_pkey;
ALTER TABLE IF EXISTS ONLY public.forum_replies DROP CONSTRAINT IF EXISTS forum_replies_pkey;
ALTER TABLE IF EXISTS ONLY public.forum_categories DROP CONSTRAINT IF EXISTS forum_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.event_attendees DROP CONSTRAINT IF EXISTS event_attendees_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.doc_library_items DROP CONSTRAINT IF EXISTS doc_library_items_pkey;
ALTER TABLE IF EXISTS ONLY public.doc_categories DROP CONSTRAINT IF EXISTS doc_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.connections DROP CONSTRAINT IF EXISTS connections_pkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_posts DROP CONSTRAINT IF EXISTS blog_posts_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_categories DROP CONSTRAINT IF EXISTS blog_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_pkey;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_blocker_id_blocked_id_key;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS ONLY public.albums DROP CONSTRAINT IF EXISTS albums_pkey;
ALTER TABLE IF EXISTS ONLY public.album_media DROP CONSTRAINT IF EXISTS album_media_pkey;
ALTER TABLE IF EXISTS ONLY public.activity_logs DROP CONSTRAINT IF EXISTS activity_logs_pkey;
DROP TABLE IF EXISTS public.webhook_events;
DROP TABLE IF EXISTS public.verification_tokens;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.subscriptions;
DROP TABLE IF EXISTS public.resources;
DROP TABLE IF EXISTS public.reports;
DROP TABLE IF EXISTS public.refresh_tokens;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.profiles;
DROP TABLE IF EXISTS public.posts;
DROP TABLE IF EXISTS public.pillar_submissions;
DROP TABLE IF EXISTS public.password_reset_tokens;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.notification_preferences;
DROP TABLE IF EXISTS public.milestones;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.matches;
DROP TABLE IF EXISTS public.likes;
DROP TABLE IF EXISTS public.investments;
DROP TABLE IF EXISTS public.groups;
DROP TABLE IF EXISTS public.group_messages;
DROP TABLE IF EXISTS public.group_members;
DROP TABLE IF EXISTS public.forum_threads;
DROP TABLE IF EXISTS public.forum_replies;
DROP TABLE IF EXISTS public.forum_categories;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.event_attendees;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.doc_library_items;
DROP TABLE IF EXISTS public.doc_categories;
DROP TABLE IF EXISTS public.connections;
DROP TABLE IF EXISTS public.comments;
DROP TABLE IF EXISTS public.blog_posts;
DROP TABLE IF EXISTS public.blog_categories;
DROP TABLE IF EXISTS public.blocks;
DROP TABLE IF EXISTS public.alembic_version;
DROP TABLE IF EXISTS public.albums;
DROP TABLE IF EXISTS public.album_media;
DROP TABLE IF EXISTS public.activity_logs;
DROP TYPE IF EXISTS public.reportstatus;
DROP TYPE IF EXISTS public.poststatus;
DROP TYPE IF EXISTS public.postprivacy;
DROP TYPE IF EXISTS public.mediatype;
DROP TYPE IF EXISTS public.matchstatus;
DROP TYPE IF EXISTS public.eventstatus;
DROP TYPE IF EXISTS public.attendeestatus;
DROP TYPE IF EXISTS public.albumtype;
--
-- Name: albumtype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.albumtype AS ENUM (
    'photo',
    'video',
    'mixed'
);


--
-- Name: attendeestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.attendeestatus AS ENUM (
    'going',
    'maybe',
    'not_going'
);


--
-- Name: eventstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.eventstatus AS ENUM (
    'draft',
    'published',
    'cancelled',
    'completed'
);


--
-- Name: matchstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.matchstatus AS ENUM (
    'PENDING',
    'ACCEPTED',
    'DECLINED'
);


--
-- Name: mediatype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.mediatype AS ENUM (
    'photo',
    'video'
);


--
-- Name: postprivacy; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.postprivacy AS ENUM (
    'public',
    'connections_only',
    'private'
);


--
-- Name: poststatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.poststatus AS ENUM (
    'draft',
    'published'
);


--
-- Name: reportstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reportstatus AS ENUM (
    'pending',
    'reviewed',
    'dismissed'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_logs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    activity_type character varying(100) NOT NULL,
    description text NOT NULL,
    target_type character varying(50),
    target_id character varying(36),
    meta_data json NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: album_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.album_media (
    id uuid NOT NULL,
    album_id uuid NOT NULL,
    url character varying(512) NOT NULL,
    thumb_url character varying(512),
    media_type public.mediatype NOT NULL,
    caption text,
    width integer,
    height integer,
    order_index integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: albums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.albums (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    cover_media_url character varying(512),
    author_id uuid NOT NULL,
    album_type public.albumtype NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blocks (
    id uuid NOT NULL,
    blocker_id uuid NOT NULL,
    blocked_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: blog_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_categories (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_posts (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    content text NOT NULL,
    excerpt text,
    cover_image character varying(512),
    author_id uuid NOT NULL,
    category_id uuid,
    tags character varying(500) NOT NULL,
    status public.poststatus NOT NULL,
    is_featured boolean NOT NULL,
    view_count integer NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    id uuid NOT NULL,
    post_id uuid NOT NULL,
    author_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connections (
    id uuid NOT NULL,
    follower_id uuid NOT NULL,
    following_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: doc_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_categories (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: doc_library_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_library_items (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    file_url character varying(512) NOT NULL,
    file_type character varying(50) NOT NULL,
    file_size integer,
    thumbnail_url character varying(512),
    category_id uuid,
    author_id uuid NOT NULL,
    tags character varying(500) NOT NULL,
    download_count integer NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    uploader_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    storage_key character varying(500) NOT NULL,
    file_url text NOT NULL,
    file_type character varying(50) NOT NULL,
    file_size integer DEFAULT 0 NOT NULL,
    category character varying(100),
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_attendees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_attendees (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status public.attendeestatus NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    location character varying(255),
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone,
    is_virtual boolean NOT NULL,
    meeting_url character varying(512),
    cover_image_url character varying(512),
    max_attendees integer,
    organizer_id uuid NOT NULL,
    status public.eventstatus NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: forum_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forum_categories (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    icon character varying(64),
    display_order integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: forum_replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forum_replies (
    id uuid NOT NULL,
    thread_id uuid NOT NULL,
    author_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: forum_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forum_threads (
    id uuid NOT NULL,
    category_id uuid NOT NULL,
    author_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    is_pinned boolean NOT NULL,
    is_locked boolean NOT NULL,
    view_count integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_members (
    id uuid NOT NULL,
    group_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role character varying(50) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: group_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_messages (
    id uuid NOT NULL,
    group_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id uuid NOT NULL,
    creator_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    visibility character varying(50) NOT NULL,
    cover_image_url text,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: investments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investments (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    investor_id uuid NOT NULL,
    amount double precision NOT NULL,
    status character varying(50) NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.likes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    post_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matches (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    mentor_id uuid,
    investor_id uuid,
    status public.matchstatus NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    content text NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.milestones (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    due_date timestamp with time zone,
    budget double precision,
    is_funding_trigger boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    matches boolean DEFAULT true NOT NULL,
    messages boolean DEFAULT true NOT NULL,
    milestones boolean DEFAULT true NOT NULL,
    activity boolean DEFAULT true NOT NULL,
    email_matches boolean DEFAULT true NOT NULL,
    email_messages boolean DEFAULT true NOT NULL,
    email_milestones boolean DEFAULT true NOT NULL,
    email_activity boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    notification_type character varying(50) NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_used boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: pillar_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pillar_submissions (
    id character varying NOT NULL,
    pillar character varying(32) NOT NULL,
    video_size integer NOT NULL,
    user_id uuid,
    storage_url text,
    created_at timestamp without time zone
);


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id uuid NOT NULL,
    author_id uuid NOT NULL,
    content text NOT NULL,
    media_urls jsonb NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    privacy public.postprivacy NOT NULL
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_specific_data jsonb NOT NULL,
    video_submission_url text,
    onboarding_responses jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    innovator_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    tagline character varying(500),
    description text,
    sector character varying(100) NOT NULL,
    sub_sector character varying(100),
    stage character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    target_amount double precision,
    raised_amount double precision NOT NULL,
    budget_breakdown jsonb NOT NULL,
    cover_image_url text,
    pitch_deck_url text,
    website_url text,
    video_url text,
    team_members jsonb NOT NULL,
    milestones_enabled boolean NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_revoked boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id uuid NOT NULL,
    reporter_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id character varying(36) NOT NULL,
    reason character varying(255) NOT NULL,
    description text,
    status public.reportstatus NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resources (
    id uuid NOT NULL,
    author_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    url text,
    resource_type character varying(50) NOT NULL,
    sector character varying(100),
    tags jsonb NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    stripe_subscription_id character varying(255),
    stripe_price_id character varying(255),
    tier character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    current_period_start timestamp with time zone,
    current_period_end timestamp with time zone,
    cancel_at_period_end boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    avatar_url text,
    role character varying(50) NOT NULL,
    bio text,
    skills jsonb NOT NULL,
    sectors_of_interest jsonb NOT NULL,
    onboarding_completed boolean NOT NULL,
    membership_tier character varying(50) NOT NULL,
    stripe_customer_id character varying(255),
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_super_admin boolean DEFAULT false NOT NULL,
    is_email_verified boolean DEFAULT false NOT NULL,
    email_verified_at timestamp with time zone,
    membership_agreed_at timestamp with time zone,
    email_alerts boolean DEFAULT false NOT NULL
);


--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_used boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_events (
    id uuid NOT NULL,
    event_id character varying(255) NOT NULL,
    event_type character varying(100) NOT NULL,
    source character varying(50) DEFAULT 'stripe'::character varying NOT NULL,
    payload text,
    created_at timestamp with time zone NOT NULL
);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_logs (id, user_id, activity_type, description, target_type, target_id, meta_data, created_at) FROM stdin;
9d3ec2d8-5017-4270-8837-cf6fe19ff43d	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	forum_thread_created	Created forum thread 'Test thread'	forum_thread	23256b9a-a0e9-4311-a012-4e91a8d20da8	{}	2026-06-30 05:28:15.917371+00
\.


--
-- Data for Name: album_media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.album_media (id, album_id, url, thumb_url, media_type, caption, width, height, order_index, created_at) FROM stdin;
\.


--
-- Data for Name: albums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.albums (id, title, description, cover_media_url, author_id, album_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
f1e2d3c4b5a6
\.


--
-- Data for Name: blocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blocks (id, blocker_id, blocked_id, created_at) FROM stdin;
\.


--
-- Data for Name: blog_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_categories (id, name, slug, description, created_at) FROM stdin;
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_posts (id, title, slug, content, excerpt, cover_image, author_id, category_id, tags, status, is_featured, view_count, published_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comments (id, post_id, author_id, content, created_at, updated_at) FROM stdin;
84aa65c6-f8a2-478f-85cf-0c0e73f62301	97c39dcc-9fe0-4bdd-939a-3f16017b3f87	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	testing the comments 	2026-06-29 10:17:51.690772+00	\N
\.


--
-- Data for Name: connections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.connections (id, follower_id, following_id, created_at) FROM stdin;
\.


--
-- Data for Name: doc_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_categories (id, name, slug, description, created_at) FROM stdin;
\.


--
-- Data for Name: doc_library_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_library_items (id, title, description, file_url, file_type, file_size, thumbnail_url, category_id, author_id, tags, download_count, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, project_id, uploader_id, filename, storage_key, file_url, file_type, file_size, category, is_deleted, created_at) FROM stdin;
c13950dc-1391-4a7c-9b07-37d5f3decffa	062edf9f-16b2-4b1d-9130-9c10d124e642	25425973-187a-411d-a306-e0ea2ca1f7ad	pitch-deck.txt	5864382599284b6dadb6890a66ed70b1.txt	http://localhost:9000/solhub/5864382599284b6dadb6890a66ed70b1.txt	text/plain	22	\N	f	2026-06-27 23:35:44.862422+00
3ff61519-1c17-4e5d-a054-7bbfdc129074	062edf9f-16b2-4b1d-9130-9c10d124e642	25425973-187a-411d-a306-e0ea2ca1f7ad	pitch-deck.txt	a247677a8b7b4da4b9d2aa013836d3b6.txt	http://localhost:9000/solhub/a247677a8b7b4da4b9d2aa013836d3b6.txt	text/plain	22	\N	f	2026-06-27 23:35:44.878283+00
\.


--
-- Data for Name: event_attendees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_attendees (id, event_id, user_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, title, description, location, start_time, end_time, is_virtual, meeting_url, cover_image_url, max_attendees, organizer_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forum_categories (id, name, slug, description, icon, display_order, created_at) FROM stdin;
5e7e6716-c451-4039-9ff0-c459075686fa	General Discussion	general	Talk about anything related to SOL Hub	💬	1	2026-06-29 10:46:20.045022+00
\.


--
-- Data for Name: forum_replies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forum_replies (id, thread_id, author_id, content, created_at, updated_at) FROM stdin;
fa675b28-be05-4538-87c0-52a14bfe06a3	23256b9a-a0e9-4311-a012-4e91a8d20da8	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	test reply	2026-06-30 08:50:36.732516+00	\N
\.


--
-- Data for Name: forum_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forum_threads (id, category_id, author_id, title, content, is_pinned, is_locked, view_count, created_at, updated_at) FROM stdin;
23256b9a-a0e9-4311-a012-4e91a8d20da8	5e7e6716-c451-4039-9ff0-c459075686fa	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	Test thread	this is a new forum test	f	f	2	2026-06-30 05:28:15.913042+00	2026-06-30 08:50:36.730972+00
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_members (id, group_id, user_id, role, created_at) FROM stdin;
4e9f537b-860e-4c4b-956e-46e9808d0642	5e18b9c1-fa5e-4330-a1d7-b1feafe36252	969dcad9-96a1-4b5f-8a0e-821a4644ff55	creator	2026-06-27 09:52:24.560023+00
887c7863-1cd6-42b9-af83-5e489cc347a9	5e18b9c1-fa5e-4330-a1d7-b1feafe36252	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	member	2026-06-28 01:16:53.899522+00
d6305cdb-5b40-4561-98be-1174736dfe60	2e479c0d-e392-4adc-9a76-0d1f19256346	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	creator	2026-06-28 01:17:16.151781+00
\.


--
-- Data for Name: group_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_messages (id, group_id, sender_id, content, created_at) FROM stdin;
d3fe1198-2f3f-4ff8-81ec-6431936c1eac	2e479c0d-e392-4adc-9a76-0d1f19256346	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	Hello from test!	2026-06-29 06:15:48.255011+00
468cffb5-aee8-4467-ad2b-d41826f7037d	5e18b9c1-fa5e-4330-a1d7-b1feafe36252	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	Greetings	2026-06-29 06:18:45.957118+00
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, creator_id, name, description, visibility, cover_image_url, is_deleted, created_at, updated_at) FROM stdin;
5e18b9c1-fa5e-4330-a1d7-b1feafe36252	969dcad9-96a1-4b5f-8a0e-821a4644ff55	CleanTech Innovators	For founders building in clean technology	public	\N	f	2026-06-27 09:52:24.554676+00	\N
2e479c0d-e392-4adc-9a76-0d1f19256346	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	Test Group	\N	private	\N	f	2026-06-28 01:17:16.149703+00	\N
\.


--
-- Data for Name: investments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investments (id, project_id, investor_id, amount, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.likes (id, user_id, post_id, created_at) FROM stdin;
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matches (id, project_id, mentor_id, investor_id, status, notes, created_at, updated_at) FROM stdin;
83950d39-955d-47a1-816b-dbfbfe96e861	7422b795-cfc9-4733-a97a-f79fa3473039	\N	0542816d-c2ce-4a55-9be4-dd530d1bb94b	PENDING	Interested in this project!	2026-06-27 23:33:32.668658+00	\N
b7a82208-b51f-447a-8a5c-5831c20c460a	062edf9f-16b2-4b1d-9130-9c10d124e642	\N	6fbb9184-d171-4425-9e23-14a6959dc992	ACCEPTED	Love this AI tutoring idea!	2026-06-27 23:35:44.563187+00	2026-06-27 23:35:44.626804+00
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, project_id, sender_id, content, is_read, created_at) FROM stdin;
be21cbed-9ea7-489c-b847-c7cbc24d024c	4e6cd4ce-4884-4b6a-b584-728d612c7a28	78e99e33-b65e-44da-a653-8c93e3c0f1f7	Hello from E2E test! Welcome to the workspace.	f	2026-06-27 23:31:24.580646+00
87e2247d-11dc-48fb-acee-459cd17de2d6	7422b795-cfc9-4733-a97a-f79fa3473039	059bc0a7-7ed9-40e1-b0a1-de241da461a5	Hello from innovator! Welcome to workspace.	f	2026-06-27 23:33:32.82167+00
60b276b1-048b-47b1-b856-8115ddde52d2	7422b795-cfc9-4733-a97a-f79fa3473039	059bc0a7-7ed9-40e1-b0a1-de241da461a5	Hello from innovator! Welcome to workspace.	f	2026-06-27 23:33:32.833087+00
86a62566-5b97-4dde-abce-345ace998894	062edf9f-16b2-4b1d-9130-9c10d124e642	25425973-187a-411d-a306-e0ea2ca1f7ad	Welcome Bob! Excited to have you on board.	f	2026-06-27 23:35:44.748613+00
bae0f5e7-984a-49d6-83fd-16df30a24bb5	062edf9f-16b2-4b1d-9130-9c10d124e642	6fbb9184-d171-4425-9e23-14a6959dc992	Thanks Alice! Looking forward to working together.	f	2026-06-27 23:35:44.788894+00
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.milestones (id, project_id, title, description, status, due_date, budget, is_funding_trigger, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_preferences (id, user_id, matches, messages, milestones, activity, email_matches, email_messages, email_milestones, email_activity, created_at, updated_at) FROM stdin;
9f167d94-fb45-4163-8438-d93a10a83c5c	71010be4-dff0-468a-9971-ddb378684531	f	t	t	t	t	f	t	t	2026-06-28 01:11:30.908973+00	2026-06-28 01:11:35.737137+00
f0f1f25f-faab-459e-8e68-67a69850e257	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	t	t	t	t	t	t	t	t	2026-06-28 01:22:14.334723+00	2026-06-28 01:22:14.334729+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, title, message, notification_type, is_read, created_at) FROM stdin;
fe24ea7c-7f08-4b71-aee4-eaf2544ce89f	8be76b94-0b77-4126-8844-fca5faf0ff90	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 00:09:31.489802+00
57155538-aadd-449d-a3df-ffae68267139	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 00:09:31.491324+00
5937d694-7b08-4f84-b69c-aaef12a6e56a	8be76b94-0b77-4126-8844-fca5faf0ff90	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 01:02:57.812812+00
d690bb17-1547-44ad-9ee2-6e3706c54743	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 01:02:57.814281+00
e27c6cab-7ecd-4d0a-a0fc-c2a3c4703b76	8be76b94-0b77-4126-8844-fca5faf0ff90	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 01:05:36.288543+00
97736522-3eb1-4fa6-9ff5-cf274259148e	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 01:05:36.289139+00
3f0eb4af-e982-4047-823b-6e3d1ef1bdb7	8be76b94-0b77-4126-8844-fca5faf0ff90	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 01:40:22.803095+00
d9cb9131-7987-4f55-9532-349f7dca0e82	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 01:40:22.80388+00
a98f6905-786f-42bc-8a12-8593815aa22e	8be76b94-0b77-4126-8844-fca5faf0ff90	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	f	2026-06-30 07:49:29.310826+00
dc9babf1-fa12-4634-a831-d3546cee48b6	8be76b94-0b77-4126-8844-fca5faf0ff90	New Mentors Video Submission	A new member submitted a video introduction for Mentors. Review it in the admin panel.	pillar_submission	f	2026-06-30 07:59:43.208496+00
71cbd586-4ce5-448e-9bd8-1b3b0084e994	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	New Mentors Video Submission	A new member submitted a video introduction for Mentors. Review it in the admin panel.	pillar_submission	t	2026-06-30 07:59:43.209168+00
eed66b47-52d5-4de7-9205-f3149afb33d7	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	New Innovators Video Submission	A new member submitted a video introduction for Innovators. Review it in the admin panel.	pillar_submission	t	2026-06-30 07:49:29.31151+00
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, is_used, created_at) FROM stdin;
\.


--
-- Data for Name: pillar_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pillar_submissions (id, pillar, video_size, user_id, storage_url, created_at) FROM stdin;
8947d79e-6f8f-4ca9-94aa-b94aeeab6afe	innovators	123456	\N	\N	2026-06-30 00:04:51.187872
bccd55fa-933f-4a83-9a6f-08e0f82e2eae	innovators	10240	\N	http://localhost:9000/solhub/pillar-submissions/innovators/cad4cf9b-ab0e-4317-9e52-15242b246e95?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20260630%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20260630T000524Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=0e331ab729be47a67da3928a5cc91d749f1e39801efb7b67de262877742b80c9	2026-06-30 00:05:24.130156
117a22e2-d77c-4aea-89ad-e9b72d13e8f0	innovators	10240	\N	http://localhost:9000/solhub/pillar-submissions/innovators/6ab930ef-b928-4c28-adec-d323a4eb0a8a?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20260630%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20260630T000931Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=d062641c3466012f89748891ead0ce6d5e2b04b68dc9f1d572fc99b48e093ada	2026-06-30 00:09:31.377112
6b2277ca-6ce2-46cd-98cb-3dd23d57eb90	innovators	18	\N	http://localhost:9000/solhub/pillar-submissions/innovators/6e645a04-8c6c-4645-824e-6be520f07f64?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20260630%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20260630T010257Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=3c9847ab50a366eac84d5ce937ae3cbff508aca7c3eb1f23e08765b77ce7712b	2026-06-30 01:02:57.807444
2a3d4ea7-79e0-4690-b6ff-21e136ff1d76	innovators	2059568	\N	http://localhost:9000/solhub/pillar-submissions/innovators/3c284393-117f-4fc3-943d-10a581460e50?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20260630%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20260630T010536Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=36748ad32b7f67db0d93a192c8e10d9dca8983f8a84e8388ef3ec00bf48561e6	2026-06-30 01:05:36.286535
3900e573-8eae-4d31-a072-04294656d44e	innovators	1821812	\N	http://localhost:9000/solhub/pillar-submissions/innovators/2dcaed74-0379-4e87-8105-f10856ab5c56?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20260630%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20260630T014022Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=426e90afa9022e33a199279936ac69f1b91f889cb851522db99be5e2d912597b	2026-06-30 01:40:22.800185
4e11db05-32bb-4c89-89be-744673ff6fd6	innovators	1590732	\N	http://localhost:9000/solhub/pillar-submissions/innovators/a7b6e27d-cda0-4f4a-8ea8-4c36efc0a5d2?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20260630%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20260630T074929Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=eada14d0147a8cbac281c59703062f7ba37c5a61f0a19a1d0aff4e071abfb560	2026-06-30 07:49:29.308929
f8d1fec8-e898-4f9f-beb6-91bae8c75ef2	mentors	1885	\N	http://localhost:9000/solhub/pillar-submissions/mentors/862b0237-4896-4a0f-a707-609ea06d42d9?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20260630%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20260630T075943Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=5f722b8fd53bbc1db00c3d44105a15ee3b79c29bee77e46757de41c115628b3d	2026-06-30 07:59:43.206395
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, author_id, content, media_urls, is_deleted, created_at, updated_at, privacy) FROM stdin;
9d4e9a39-78db-4ac1-9d58-a81e4a973e15	969dcad9-96a1-4b5f-8a0e-821a4644ff55	Just joined SOL Hub! Excited to connect with fellow innovators and mentors.	[]	f	2026-06-27 09:52:24.582222+00	\N	public
66b39435-762e-4584-a69a-cecc04134235	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	This is a new post test	[]	f	2026-06-28 01:20:43.058681+00	\N	public
ccf63745-42ce-4239-94ff-22c44b19d7cf	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	test	["http://localhost:9000/solhub/139e1347da4049ffaa690162216b3fcc.png"]	f	2026-06-29 06:20:16.207417+00	\N	public
aaa01360-2c7e-4a6d-b61d-e309292d7e9b	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	Test post with image	["http://localhost:9000/solhub/632d20285e2e46f19f74b35558cda97f.png"]	f	2026-06-29 06:24:14.370704+00	\N	public
97c39dcc-9fe0-4bdd-939a-3f16017b3f87	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	Updated content via PATCH	["http://localhost:9000/solhub/3a59e7ac7bb64e0189a89d834d0656fc.png"]	f	2026-06-29 06:28:32.564832+00	2026-06-29 10:18:27.966493+00	public
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, user_id, role_specific_data, video_submission_url, onboarding_responses, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, innovator_id, title, tagline, description, sector, sub_sector, stage, status, target_amount, raised_amount, budget_breakdown, cover_image_url, pitch_deck_url, website_url, video_url, team_members, milestones_enabled, is_deleted, created_at, updated_at) FROM stdin;
f7ebe678-d609-4d74-8d11-3a63c91f6ef9	fca96ccd-acc2-44ea-b1e9-4134cac2db48	Test Project	A test project	Testing the submission	EdTech	\N	idea	draft	50000	0	{}	\N	\N	\N	\N	[]	t	f	2026-06-27 02:32:12.352673+00	\N
ef688952-73e9-441d-b4b2-369bd420b6cf	0ffaa3e5-51e9-4e97-9edf-73ffc804bec1	Admin Test Project	Testing admin	desc	EdTech	\N	idea	draft	10000	0	{}	\N	\N	\N	\N	[]	t	f	2026-06-27 02:39:44.161319+00	\N
4e6cd4ce-4884-4b6a-b584-728d612c7a28	78e99e33-b65e-44da-a653-8c93e3c0f1f7	E2E Test Project	Automated testing platform	A project created during end-to-end testing	education	edtech	prototype	draft	50000	0	{}	\N	\N	\N	\N	[]	t	f	2026-06-27 23:31:24.050251+00	\N
7422b795-cfc9-4733-a97a-f79fa3473039	059bc0a7-7ed9-40e1-b0a1-de241da461a5	E2E Project	Test	Testing	education	\N	prototype	draft	50000	0	{}	\N	\N	\N	\N	[]	t	f	2026-06-27 23:33:32.272622+00	\N
062edf9f-16b2-4b1d-9130-9c10d124e642	25425973-187a-411d-a306-e0ea2ca1f7ad	AI Tutoring Platform	Personalized AI tutor for K-12	An adaptive learning platform using AI	education	edtech	prototype	draft	150000	0	{}	\N	\N	\N	\N	[]	t	f	2026-06-27 23:35:44.184394+00	\N
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, is_revoked, created_at) FROM stdin;
953af894-2c4a-47c9-a2b3-20ee8a9c2a95	961ea04c-d4b5-450e-99b5-f0c025be5488	82c76d3a0ff0b2218a876a442c4957569011a63737a919447195ce4b5f90706c	2026-07-04 02:11:55.964807+00	f	2026-06-27 02:11:55.965701+00
652ed566-afae-42bb-badb-eb062de684a5	961ea04c-d4b5-450e-99b5-f0c025be5488	e2135fd321225467726135e07f1abcc5f7dc6d86273f6015f535d0e9e384291e	2026-07-04 02:12:18.447658+00	f	2026-06-27 02:12:18.449003+00
dd8f5d1d-81fd-4014-9082-191705f5168b	961ea04c-d4b5-450e-99b5-f0c025be5488	45f0fb96facff558d99b3bb380d5d0283c284054fbf17957cd5d6fd9484f0450	2026-07-04 02:12:51.04692+00	f	2026-06-27 02:12:51.048344+00
21a9b5e7-5eaf-4422-b93b-f730919f0611	b8e46d2e-6ee6-4b27-a26e-c2a09c9ecead	e997a10438254277fa27a091e9a7bbc4abc6f32b92487945cc675d3f7b7899b8	2026-07-04 02:13:42.678984+00	f	2026-06-27 02:13:42.680091+00
54e5d4f9-3e7b-43ea-a1de-a75df7ca54ce	1a229b60-a70b-4919-b1ab-f709b631603a	6ee7419aa97379547205fa0789f37ffbf7b0daa64d6068e46984a9aec12426ba	2026-07-04 02:17:43.593875+00	f	2026-06-27 02:17:43.594755+00
8d3f6eaa-5b1b-4aa8-ac64-cd3842378956	7b708cdf-f5c7-421b-9820-382ceb0c83d5	9ab632bac9fe7c2235fb0d3a69a91333355b917a7429072d6cfcd34201b360df	2026-07-04 02:21:50.905628+00	f	2026-06-27 02:21:50.906891+00
00683802-c523-4d83-b382-efeb1beedf6e	02b2ccb6-d3ef-46e9-9e71-1af4914cd986	67dbeb75b2f522bdf3c6d2a09083a8740aff234264539dd592b6e45af9f89209	2026-07-04 02:28:08.40636+00	f	2026-06-27 02:28:08.407136+00
7d004658-fa56-40ce-a508-9e2e1727a9c0	fca96ccd-acc2-44ea-b1e9-4134cac2db48	674d263311dd50aa390c004245ada9d49e8a16ea8a11223ca8483294b1bbdf15	2026-07-04 02:32:12.311395+00	f	2026-06-27 02:32:12.31173+00
ba645d4c-1728-4b79-b218-311231a9ce84	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	d801c67aad7f3e2ce8c068d817cf042e67f46968ebb3f358036281f1c897b791	2026-07-04 02:33:57.719129+00	f	2026-06-27 02:33:57.720002+00
b47fa32f-e08a-4854-b5b2-8320f60d802d	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	0872e30db4da1ac77886584c4d615a489535ef9f6d932a2db202b757a1d77d21	2026-07-04 02:34:03.024964+00	f	2026-06-27 02:34:03.025381+00
da196164-0a55-441f-8042-10d55b1d4e1c	0ffaa3e5-51e9-4e97-9edf-73ffc804bec1	83aa0c9c30006245662bbeb023ed4c7afc458714f2f4356155533faf5ddb8c0e	2026-07-04 02:39:44.116354+00	f	2026-06-27 02:39:44.117194+00
68878982-1041-48c4-a9c8-116aa9b4128d	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	824517fcd709d24a6ce24d362e0460eead8e0b9c6a1492d9453a582ea217aa59	2026-07-04 02:40:09.571382+00	f	2026-06-27 02:40:09.571762+00
3f7d6b7b-db61-4230-9d54-43d08fa7e648	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	18de8f1c87e52bf4d08f71531ec06651daa099202019608bdb998d2cb493d809	2026-07-04 02:41:00.467972+00	f	2026-06-27 02:41:00.468334+00
7c75b0f2-0b1f-4aee-af5f-ffc8696a9bef	1a229b60-a70b-4919-b1ab-f709b631603a	0913ebe6dfa9632452649508653a0ce9e2467a1c595cbb6ab1ff6251224b98e6	2026-07-04 08:43:38.209163+00	f	2026-06-27 08:43:38.209638+00
4b84f65c-ec18-42c3-ae54-819bd6bae09e	1a229b60-a70b-4919-b1ab-f709b631603a	67141bc55f4ad9081904dfdacb364cc2fe9d5f09c04670f24fee8a26839ab1b8	2026-07-04 08:49:13.193661+00	f	2026-06-27 08:49:13.194019+00
a2842945-fd6f-4696-a5eb-32e45a94097c	969dcad9-96a1-4b5f-8a0e-821a4644ff55	00f08f07e173cc76a50e5c0ccdec310eda661a02563e07abec13619c451d749f	2026-07-04 09:52:12.903734+00	f	2026-06-27 09:52:12.904826+00
ddec7d4b-0878-48e7-aad2-0786a8823001	1a229b60-a70b-4919-b1ab-f709b631603a	4c80f53d934ef8fb1062e7b5651f756c38914648eac1ea2c292f5fd695c99ec4	2026-07-04 19:30:34.057473+00	f	2026-06-27 19:30:34.059007+00
65d45c3a-1535-49f4-a5d1-7da68efb27bf	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	5868b2fdefb16aef0b6400dd8317b5f249cc1c5b8809c2b94e2f69d49acdb61e	2026-07-04 19:33:47.188669+00	f	2026-06-27 19:33:47.18907+00
cc704cbd-b9d5-44a9-b929-dc8ac2a8c433	78e99e33-b65e-44da-a653-8c93e3c0f1f7	d9e382c5566f2af33ba81b3848e659c4dba810318f523a6d24e03a675b05d801	2026-07-04 23:31:23.944697+00	f	2026-06-27 23:31:23.945032+00
dd696bc7-497c-4aad-ac98-0e14ff19f177	7f2981f9-195d-4d51-98c5-864bbfb5e98b	26a4b0e26acc4e4c591ff233c9c28710492a57ebe68e33505d6d9e52dd3a9ff7	2026-07-04 23:31:24.326869+00	f	2026-06-27 23:31:24.327446+00
05dbd463-eb85-436d-9352-2b99a76f0e5e	7f2981f9-195d-4d51-98c5-864bbfb5e98b	15d1730e8427f83d7d0d4514057c4d33f7d2750d0ead3d52ae6f85dd2192f735	2026-07-04 23:31:44.430904+00	f	2026-06-27 23:31:44.431341+00
f10bdcff-93fc-411e-a7fe-3294ae514ccd	78e99e33-b65e-44da-a653-8c93e3c0f1f7	899007ee3d9769e01ea4ad866dd89217c7919eb48e942bdc17ac0e921b9d94bb	2026-07-04 23:31:51.007746+00	f	2026-06-27 23:31:51.008141+00
eb28cb23-23ba-4a6c-b9ae-1c0c59c68297	78e99e33-b65e-44da-a653-8c93e3c0f1f7	4588b389da32b821ed648bacc83b55c8e6ec72d74e0e015153ffaf2a10a1c6a9	2026-07-04 23:32:00.008579+00	f	2026-06-27 23:32:00.008942+00
c95280d3-11ba-4d48-8b3c-098eb7cb7c46	78e99e33-b65e-44da-a653-8c93e3c0f1f7	0067b0e50a4547ea06729bd784236669538fbf88c53fe225f9cb86dad7463aef	2026-07-04 23:32:37.214631+00	f	2026-06-27 23:32:37.21599+00
9208050d-b676-4167-bc7e-bff1bb60d556	059bc0a7-7ed9-40e1-b0a1-de241da461a5	f45f654723548661206dd7b545e2ce3fe595f3e6205fbc13fdd86229ab0c9ce4	2026-07-04 23:33:32.173484+00	f	2026-06-27 23:33:32.173771+00
30427556-25ea-4e43-bb82-1de60cb9a8fa	0542816d-c2ce-4a55-9be4-dd530d1bb94b	ef6774e4cbe370354887370ed32d78e91f0a6c56ba16463ada4454ba49199dae	2026-07-04 23:33:32.526005+00	f	2026-06-27 23:33:32.526259+00
074818d3-f87c-4929-a3d9-df424676f41d	059bc0a7-7ed9-40e1-b0a1-de241da461a5	63fec970646fda05e9af64e9bada30f94980a0e49ab9237b1c7ffe3d424cbdc1	2026-07-04 23:34:32.927814+00	f	2026-06-27 23:34:32.929234+00
80088534-2985-43ec-9f60-88675f427f40	059bc0a7-7ed9-40e1-b0a1-de241da461a5	24b0504748757cafc77a5f2fe4cf02b3a29bd23cced93d7ce4e5b516d5abe1e2	2026-07-04 23:34:42.605473+00	f	2026-06-27 23:34:42.606896+00
4bee7d20-40ec-4b9f-8d9f-be83f7c9925d	25425973-187a-411d-a306-e0ea2ca1f7ad	ea573718203b026e0da0d013c59a07be8e3d5e0d3c4de07392b6ec4dd3147134	2026-07-04 23:35:44.085607+00	f	2026-06-27 23:35:44.086509+00
a2180087-d113-43d3-a35d-d1598482a7e6	6fbb9184-d171-4425-9e23-14a6959dc992	61f74a9f2e24961ae0be53fe6be57e481f99d328a15df40a88e5fb12cd360633	2026-07-04 23:35:44.440107+00	f	2026-06-27 23:35:44.440413+00
d3cf5438-1300-42ae-b093-98976ee09232	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	d418e693331c7f8f39dfc18d11fb51995f720e604d5f9b4276faf78cacb5fea3	2026-07-05 00:19:14.342165+00	f	2026-06-28 00:19:14.343663+00
9934860e-2ef4-489d-9605-16e9295a40de	71010be4-dff0-468a-9971-ddb378684531	27f03aeb45926f586417cd6f05a50b51ec5693948bd9c104d8c9325b7749914e	2026-07-05 01:09:56.173965+00	f	2026-06-28 01:09:56.174905+00
89a82134-68c1-42a4-8112-3e3f86c01406	46ec93b5-a462-490a-9d72-02065b706e89	376bbed0d837677212377fc486201591f3cda709ba264892ec14b78890627d6a	2026-07-05 01:10:02.394158+00	f	2026-06-28 01:10:02.39446+00
3606fca2-e8ce-467c-9961-bb9cb6fa04c0	bc2519a9-472f-4a26-9e91-90a1a0410068	5d7c641ab77384c7472607faae11e73ecabc38d8ae835593763132b189831824	2026-07-05 01:10:02.634288+00	f	2026-06-28 01:10:02.63455+00
4bdfaa1a-691e-4cef-890b-8adcc6b6b3f2	20312500-0600-450b-af3b-f26fc42ab6c5	548daa2564c19ae70a4a1b57e9a40545d8c621da29b6696f8a5b9a375c98ebce	2026-07-05 01:10:02.873573+00	f	2026-06-28 01:10:02.873835+00
bdc36864-623b-4c4a-a632-83f56b93e261	9beaec8b-607f-41e4-969b-33e311282045	728b10c55077115224018b853bc01147661202a0943f6221262eb44641f7de75	2026-07-05 01:10:03.112434+00	f	2026-06-28 01:10:03.112696+00
8c830712-766a-453f-899a-3d0372f34f00	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	935760f8b9d306a8898a8ae5feb014e79c50a108f5a4b410b6aae2fb8ad78a9b	2026-07-05 01:14:37.233128+00	f	2026-06-28 01:14:37.23407+00
6717470b-7151-44bc-911a-5908186367c9	71010be4-dff0-468a-9971-ddb378684531	86524067fa1c8b84fba2e9d18d625bc70bec6c95b334e56bb3f5a54d2b2cf0dc	2026-07-05 01:30:14.342781+00	f	2026-06-28 01:30:14.344169+00
9fe56ed6-29b7-4046-a2f3-dd7cd836fe06	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	8075a321c1c1944ac758faf10533335f3ee3d027b9c12b4ba9d32e1720b11db9	2026-07-05 01:31:11.437834+00	f	2026-06-28 01:31:11.438238+00
5eded7a9-bff7-4bdb-b70d-338bf8997f39	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	21a709b11f47691bac20a6f4def4515cbdfb037b5a733f9a3af1da80db63b4c5	2026-07-05 01:31:32.937568+00	f	2026-06-28 01:31:32.939401+00
6054f9fe-fa87-462d-9cc0-0ee46c6656ee	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	da23af555963df5ed0fcee4e5573504109288c022de3c16eb9e6e0a81d166ff3	2026-07-06 05:49:46.163088+00	f	2026-06-29 05:49:46.181097+00
ce0a23ed-9b34-4241-8a4f-b133a5379367	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	c1709f7c75c87d98edcd02d7878999c3f289c4f0db6fe37f82aa82ff55351124	2026-07-06 05:50:36.810913+00	f	2026-06-29 05:50:36.811299+00
8008b16b-53ba-4231-8261-260e657e9b59	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	afd8f58567d586937d59e59129ad85df2ad000a768eebb9fc6819794c4d24f11	2026-07-06 05:50:47.297159+00	f	2026-06-29 05:50:47.297563+00
e22a0952-15a4-4307-b7c5-4fa5481e615a	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	9287611811985bcc024144b479f93e11644f3536f2d1ee99701093ffa06ed986	2026-07-06 05:51:18.316728+00	f	2026-06-29 05:51:18.317085+00
09ccfd64-5b5f-4471-9439-71ff30cb1762	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	bb43fa02bfb91959dc0ecd2988a6adae9eef400fe8d72059710a95673dc383e0	2026-07-06 05:55:36.209073+00	f	2026-06-29 05:55:36.209537+00
86baa666-8a1a-4759-9558-3f3f4a850b70	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	85bcc42e03b9288f5326fd57e49555baa67cb9427c8e2c63633233c94a2e780f	2026-07-06 05:55:40.977727+00	f	2026-06-29 05:55:40.978087+00
ca722a34-cdb3-4acb-a3fa-cf746cfa1235	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	a7d336479b3d3661e2221f9609e9c0feb588b8ba46f3b997deed95fee86a5616	2026-07-06 06:15:11.130531+00	f	2026-06-29 06:15:11.130917+00
c4ac7013-0b50-4b2e-9521-8cb023ae8154	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	db221eb4acab446fe94b9182d16f0fec267eb71981672d0c09ab5312fe2d3abc	2026-07-06 06:27:20.144006+00	f	2026-06-29 06:27:20.145085+00
7edf5d4d-2450-4911-81c4-4c6f4500cf49	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	95da798992478274ae4e8274547931492a9939e1a123fb027f04aad21d0acedd	2026-07-06 06:33:27.301686+00	f	2026-06-29 06:33:27.302966+00
660b314d-3baa-49b6-96e0-3cf19d4fc149	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	9421d971a50b83d5592cf179a65c1edb67ab05b480dd8c58404f5b19510cc327	2026-07-06 07:01:00.964439+00	f	2026-06-29 07:01:00.965068+00
4cd265f9-4110-4a2e-9101-d9b5d5ee43bf	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	a913df9afebae8c5585ee8ec4f65dd89faee5a2d82031937fabe33359a952a6d	2026-07-06 08:31:09.312746+00	f	2026-06-29 08:31:09.313299+00
a7c38b1d-e181-4cfe-8084-f3464be2e6c9	8be76b94-0b77-4126-8844-fca5faf0ff90	46d902cb2d94b8b527d2e9b719d17be6b53afef97d11d1d1d4402fc734ffb13f	2026-07-06 08:31:20.528183+00	f	2026-06-29 08:31:20.528543+00
4b495048-389e-46a5-9623-e675397f1a24	546d665f-e252-4183-bafc-e0795d12040a	a3a6dfd43daa342603fefab73fbb13073560bf7a34c70be0e71b6f7b6d492374	2026-07-06 08:32:02.574907+00	f	2026-06-29 08:32:02.576846+00
f578bf77-18c6-49eb-a22c-71eac3ddacc5	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	f22cd06efb854fd926bae7a5c57f39f44228adbc99c1f52aa471bb5f442fcf5f	2026-07-06 08:32:06.475302+00	f	2026-06-29 08:32:06.475727+00
dea49191-7595-46e8-8887-064a44499f36	a30c1f68-275b-47c7-b83d-99654a7c3dfb	99e1f75445b54d3d7211de833d0ea9d73f2a9671cf62f97769f939c3cb83e0e7	2026-07-06 08:32:06.705334+00	f	2026-06-29 08:32:06.705766+00
0da3a052-f35e-4a10-a5eb-79fb3e29e5ff	d6940c0a-aac3-401a-915d-ad826d67bc47	904d37d1249ff9c48056ef6c5d924bab1acaa6ca0349648d13b969e17ebe95cb	2026-07-06 08:38:21.950148+00	f	2026-06-29 08:38:21.951632+00
aa36cba4-4187-452d-b123-250f0bded55d	3bd46785-7512-499d-a4e1-373e47867c32	3520a9dc68a972c7f67b7209612a0f1f8c4412d4afe282fc2e0df5978088a9df	2026-07-06 08:38:24.009731+00	f	2026-06-29 08:38:24.010143+00
8d439775-9606-41af-83cb-814a478abbd9	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	5d7881160a4bb292ca0a2e26da560e4bece361afa989ecde707758736b92c5ce	2026-07-06 08:38:26.682088+00	f	2026-06-29 08:38:26.682558+00
db581302-f6ce-41f5-8a42-cd6bd4aeb74c	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	83c04842176f2b38d92a4760900dc9a64a79d4be6f3ba6c2079ae3db92ac6d9c	2026-07-06 08:38:28.591163+00	f	2026-06-29 08:38:28.59188+00
9b81e677-b53f-4eba-9d70-4c05ce934acd	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	6d62dc7940b8d971542ad80a5331024d23423a4b652d97971775595233da2e96	2026-07-06 08:38:30.209503+00	f	2026-06-29 08:38:30.209941+00
3f83d39b-0f4b-452b-b900-183abac7055a	dafa46cc-be7a-4d3d-8c8e-b3ddd48a8c70	48af1883415d14083c20b4ce74a883c66d2577abbfb65da1eddb949af76af772	2026-07-06 08:39:49.521427+00	f	2026-06-29 08:39:49.522613+00
5c83b4ad-4008-4ce1-8e5c-6c281fcaab43	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	96e30ff0414793aef96e2b98cc35a6ef4687d605fb58c51cc33450bc9fe5eace	2026-07-06 08:39:51.786488+00	f	2026-06-29 08:39:51.786884+00
cf069dd4-6006-41a2-b764-e9d22b4ae06f	a984d505-b73d-4704-94ba-00f73cbc8a5b	cf1585a6a1709cdc30288e34fa734db648b5009cbfe304d7d36fec5bf95f75bf	2026-07-06 08:40:01.921717+00	f	2026-06-29 08:40:01.922045+00
543dc8b3-d961-44c2-983d-07de78850786	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	6c4efd69d4cb10f4d0ca925a88304c89263105457fcce680baba94423fb518a5	2026-07-06 08:40:02.24441+00	f	2026-06-29 08:40:02.244782+00
d34235e2-be3e-4a49-9b5b-2dd575a2fe2e	e9c32c35-e210-4a6a-958a-bf47ec48a4b1	e4311f8fc545b9070472ed6668e8f1c87ec40c84cea2e3eb2bec61c803fcf210	2026-07-06 08:44:07.374927+00	f	2026-06-29 08:44:07.376276+00
593576e0-9949-4ef7-9b6a-743c4c59110f	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	7dd91316d78a4808b19b4a67c84fa4ac2fd31b1f6b283bb1f8ea05065e713fca	2026-07-06 08:44:07.615634+00	f	2026-06-29 08:44:07.616035+00
5c2cf77f-f764-4597-bac1-e0ceaa04b81e	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	908a10f8513b8806215fdf0293cdf3f92e05b2d30c81d34429be4fba2751f2f4	2026-07-06 08:52:40.183168+00	f	2026-06-29 08:52:40.183545+00
3b19e56c-4a08-4862-86d7-e5a18db8ea4f	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	503f2c70f6295dda4119c159af731222deeb49e9e9b319a6bfa7c598dcbca8da	2026-07-06 09:08:05.348613+00	f	2026-06-29 09:08:05.349067+00
482e339a-3f3b-4eb1-90a4-0fb4b42943ea	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	45b8d549a73fc6f53fca8bc49b46181bf2317dadc83ffa501b9c2a8817cc56c3	2026-07-06 09:56:35.042822+00	f	2026-06-29 09:56:35.04346+00
d67f6b98-0744-4663-afb6-83fcbbe1de5c	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	2487b18a45f6958acb6db7630865ee97c039df0fe8573efb468317e03568c874	2026-07-06 09:57:04.148809+00	f	2026-06-29 09:57:04.149262+00
e19346bb-ce7c-486b-9806-004b715c6eee	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	809b68489da05ca9d4f04cf92c0cfc12b2154b590823fa1369d01a2e72d4cc33	2026-07-06 10:01:32.622443+00	f	2026-06-29 10:01:32.624581+00
c476757b-a0c9-468f-bba4-f7b7d0065120	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	16d6e0d74c4ccca6fbedd915262aff16fdb17d6a59577e3386664a7c0cd99e53	2026-07-06 10:01:37.091453+00	f	2026-06-29 10:01:37.091908+00
2ed7c957-31f5-4b37-aa20-18889838c0f1	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	03a633119a97580877b42858b038d4fc1daa06bdea687280c87ef01b2ca7231e	2026-07-06 10:01:41.459594+00	f	2026-06-29 10:01:41.459943+00
18729a57-249f-4934-9520-15463ea63de3	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	1cde5a0ce994d05d8153833a48aab5e68163a1877712ff9584def409fe4cd489	2026-07-06 10:01:45.766707+00	f	2026-06-29 10:01:45.767074+00
d87ddd16-4334-4242-9d64-3fb371563076	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	0c929485f669e18a80897a4d30cbbaba91a6e07b91955d49c2d9bcda738adb22	2026-07-06 10:01:50.821155+00	f	2026-06-29 10:01:50.821524+00
f9662786-a4b3-4d3b-8463-cbf22acdaba8	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	7f0a9cf6c91225215232234c2ef4794ca3f3724dc091726b1e268d2adf3f6fb4	2026-07-06 10:04:38.143589+00	f	2026-06-29 10:04:38.143978+00
0f5ef8d3-5408-4adb-b020-0959d3b8d0f2	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	957d6fb33d4a74085c654e296679032f4274193a21343a45be9397720fba19e5	2026-07-06 10:18:27.924259+00	f	2026-06-29 10:18:27.925768+00
8b2ee932-46ca-4e1b-8701-3dca78d267eb	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	53d7d7f2828442c2ef83d3daa9b7f03227eed17d5e2b1aaff132baaa450ec774	2026-07-06 10:33:02.889147+00	f	2026-06-29 10:33:02.890639+00
0041d2a3-bad8-4172-870e-175de2a0c163	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	a552f73ea28af8c0ac228ddcbb5b271fba3d53ae50004dc68e90da19f8a8e6e1	2026-07-06 10:35:16.54833+00	f	2026-06-29 10:35:16.551844+00
39ff7203-6124-4d4c-b366-0385ff0ec8ec	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	353d928bf505d9eeb1b69538b418e67149090f4f33d615495eaf6e91799d2b75	2026-07-06 10:42:32.07235+00	f	2026-06-29 10:42:32.073629+00
d615bc82-d581-4f80-bc98-4395427eb25e	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	9390306f126cc1a72d67a5d872dce39fe9cec57027e629961dcacdb970df1fa1	2026-07-06 10:46:20.016237+00	f	2026-06-29 10:46:20.017581+00
2b74cfac-12cd-495d-824b-b177a4a769c3	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	28a4fff20fd32f18b03836bb648b16dd329319be553177cd233fcb1864566dca	2026-07-06 17:44:34.432198+00	f	2026-06-29 17:44:34.433572+00
d47dfba4-87cf-4f91-9a92-93270f52ac52	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	57dc45e48aa9131edb480da341e4b4f54a0a3b55a6855035d10bfe11f5f83cb1	2026-07-06 21:46:29.28237+00	f	2026-06-29 21:46:29.283876+00
a8fe62b7-431b-4351-afc3-f8473f92ce44	1a229b60-a70b-4919-b1ab-f709b631603a	9ec70aaef11970a84ecce81e5a60f886109e3913bc7d4be448cbe8deb55d6998	2026-07-07 00:24:22.25199+00	f	2026-06-30 00:24:22.252849+00
a1be5470-1056-4613-933e-a56243a34964	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	900169c42e64f0741e9c6a5424dae76a050a1e1c3551f853dfe07359d9f6afef	2026-07-07 01:06:16.421981+00	f	2026-06-30 01:06:16.422526+00
0a8bed81-8d7a-404c-928c-736788542e3d	1a229b60-a70b-4919-b1ab-f709b631603a	3d5e4871d0961275620071c97924c79fa757ba2011b4f2f9de71767a0a71ca69	2026-07-07 02:41:42.569653+00	f	2026-06-30 02:41:42.570059+00
4d025fea-0120-4e72-a371-4aa041d35ac9	07b3e8e2-74a5-41a0-aac5-4820790747b3	0cfe20883464da2133307f832f2ea8d4a20d6d3cf248df8834f80dea36fc3d58	2026-07-07 03:24:23.272447+00	f	2026-06-30 03:24:23.272757+00
a9dbf81d-a65c-4335-92a7-9b71de9dd8e4	f749b035-d970-443f-a040-9e780cacce5b	3483b31a52d859a9a6962cbc24e48d3169b1e4462818a67e5a4af07a285f3293	2026-07-07 03:27:01.397748+00	f	2026-06-30 03:27:01.398051+00
ff9c56df-ea92-48d8-9020-d67180b902b7	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	6c81a684daa5aa25c4d1d1bd6804ee66f2fe8ed8c7169ffe1f5fe8f9780c11d6	2026-07-07 05:26:52.811481+00	f	2026-06-30 05:26:52.811906+00
394c56e8-6aaa-416d-9ddd-dae6ee78b3b3	4e1d9656-ed17-440a-b877-a3500be65971	0d661a383ab4fd5c212d46c57cff410d60e0505c305ed4238d9ac4fc032af5c0	2026-07-07 07:22:03.606139+00	f	2026-06-30 07:22:03.606588+00
0d5532d9-5011-4e14-b36a-4cecc4a8fa62	18ecec63-47e0-4642-8d23-172b693f3011	c262bcb9441ce4767a39aa04d9cd3570c0ef13e9c4c2ac5b5b85476271740126	2026-07-07 07:28:10.913335+00	f	2026-06-30 07:28:10.913636+00
23ba792f-1ade-4bf1-a2ca-2798405be0c6	f749b035-d970-443f-a040-9e780cacce5b	80a880d94c48379f990ba7e5baa3323ff6fd6dbe0920ca545119104976d0c46c	2026-07-07 07:48:42.231825+00	f	2026-06-30 07:48:42.232163+00
84034e85-57a3-4e74-a3ca-7867f0a2be89	1a229b60-a70b-4919-b1ab-f709b631603a	3abff934aae5b15439a4bb1cc7f0d3e5a8083677c90071c40526405889100274	2026-07-07 07:53:08.308112+00	f	2026-06-30 07:53:08.308544+00
7d813d6b-5c66-4a2e-bd4a-5794fca1b80d	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	c81f849be4ace8dc96e4f9193efc647f95cd6b1cbd8a1122397e02208a88fbb0	2026-07-07 07:57:06.437598+00	f	2026-06-30 07:57:06.437968+00
4c08c451-14ed-44fa-98b8-5f6849b8d4d2	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	53e0c02018d941227a878bcf3abcddb0e07c0fdf8a219456c7806a78b20c96d9	2026-07-07 08:48:57.76713+00	f	2026-06-30 08:48:57.767568+00
0481f1e6-98a7-4b6c-9683-185971acf33d	f749b035-d970-443f-a040-9e780cacce5b	ddf333169fb6c50369c31b73124d2059fe7a7e17ffae4b0e3c2043b10eea2be9	2026-07-07 09:39:56.679136+00	f	2026-06-30 09:39:56.679544+00
16d9748b-317e-4dd4-84eb-ac4b587fa73e	e6930429-7852-4bb5-8c7e-4333dbbeb32d	b10d634c0768ae998b319b8a05ad8b6a9327600ec7047133376bf0623431ce99	2026-07-07 09:47:08.177849+00	f	2026-06-30 09:47:08.185957+00
4a883aad-0edd-48c6-a593-4e87db643d59	e6930429-7852-4bb5-8c7e-4333dbbeb32d	b2c1266bec82f38befdadc07cdcbbddb7316a60b84664e21b96bb816cbfe3d89	2026-07-07 09:47:11.687068+00	f	2026-06-30 09:47:11.687506+00
8743629c-6f8a-477a-a30d-57514c57b221	e6930429-7852-4bb5-8c7e-4333dbbeb32d	49263c1576a982d9bbc065fe5771c1bb2f8e149e5dceab90479bf53919ddc1ba	2026-07-07 09:47:29.495633+00	f	2026-06-30 09:47:29.495968+00
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reports (id, reporter_id, target_type, target_id, reason, description, status, created_at) FROM stdin;
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resources (id, author_id, title, description, url, resource_type, sector, tags, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, user_id, stripe_subscription_id, stripe_price_id, tier, status, current_period_start, current_period_end, cancel_at_period_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, full_name, avatar_url, role, bio, skills, sectors_of_interest, onboarding_completed, membership_tier, stripe_customer_id, is_active, created_at, updated_at, is_super_admin, is_email_verified, email_verified_at, membership_agreed_at, email_alerts) FROM stdin;
961ea04c-d4b5-450e-99b5-f0c025be5488	test@solhub.com	$2b$12$pOqjDiC23f9wJx1q7x37xOKpcllDnuPzZYXSNaBYIuXNvlNICHTxS	Test User	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-27 02:11:55.962539+00	\N	f	f	\N	\N	f
b8e46d2e-6ee6-4b27-a26e-c2a09c9ecead	newuser@solhub.com	$2b$12$r3y3/sckFv4Om7.MzX//3.SAsP/qDizuRkHscYMpe9goAAopcyuR2	New User	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-27 02:13:42.676329+00	\N	f	f	\N	\N	f
7b708cdf-f5c7-421b-9820-382ceb0c83d5	onboard@test.com	$2b$12$KHuFZwoCLyh0pyfH8ckKbOaNTLAkFmLRlV3RCt3HqWRg6hPCzHJ4y	Onboard Test	\N	innovator	Test bio	["Python", "React"]	["EdTech"]	t	free	\N	t	2026-06-27 02:21:50.903196+00	2026-06-27 02:21:50.947875+00	f	f	\N	\N	f
1a229b60-a70b-4919-b1ab-f709b631603a	sb@zknet.io	$2b$12$qgaUQryGmde/feNL4IcOouy5uyZcibBDx.VDjYL7Yorvhi3Z/F.hm	SB-Test	\N	innovator	\N	["builder", "system ops", "security"]	["AgriTech"]	t	free	\N	t	2026-06-27 02:17:43.591764+00	2026-06-27 02:23:25.85831+00	f	f	\N	\N	f
02b2ccb6-d3ef-46e9-9e71-1af4914cd986	final@test.com	$2b$12$TiLph4Aax6FuuLFISOefF.9J42h6CpeS6bAdROu0K/FLw1AVhm2Hu	Final Test	\N	innovator	Done	["Python"]	["EdTech"]	t	free	\N	t	2026-06-27 02:28:08.40415+00	2026-06-27 02:28:08.448244+00	f	f	\N	\N	f
fca96ccd-acc2-44ea-b1e9-4134cac2db48	innov@test.com	$2b$12$MVTHoS2seVFNO/N0D27pheqYkgIwmzFKp/sKX7EA9s6V9o9NoXOBi	Innovator Test	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-27 02:32:12.31058+00	\N	f	f	\N	\N	f
0ffaa3e5-51e9-4e97-9edf-73ffc804bec1	innov2@test.com	$2b$12$2JeMluD6caJzk8lxCEj4IOgLUaRbAyJxas60kGRQcCxRhdhe7YUOG	Innov Two	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-27 02:39:44.114024+00	\N	f	f	\N	\N	f
8be76b94-0b77-4126-8844-fca5faf0ff90	testsec2@test.com	$2b$12$kZy3gPSLyRyxWRny3YjJEe30td0gVd0CqU1YPa1LpPFQUCDHka7.i	Hacker	\N	admin	\N	[]	[]	f	free	\N	t	2026-06-29 08:31:20.52691+00	2026-06-29 08:31:20.576781+00	f	f	\N	\N	f
546d665f-e252-4183-bafc-e0795d12040a	c1test@test.com	$2b$12$veMhPmiSePMbueLCVJMOIercqf/YhA03YvYkrZ6hcKjMJHCbLHg6q	C1 Tester	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-29 08:32:02.563042+00	\N	f	f	\N	\N	f
969dcad9-96a1-4b5f-8a0e-821a4644ff55	demo@solhub.com	$2b$12$J36kvkML1k51R5jhByiVsuQ1pMYNHmw33lCtXl7apxDNHCam3r17S	Demo User	\N	innovator	Building the future	["Python", "Rust"]	["CleanTech", "AI/ML"]	t	free	\N	t	2026-06-27 09:52:12.900465+00	2026-06-27 10:11:33.655193+00	f	f	\N	\N	f
78e99e33-b65e-44da-a653-8c93e3c0f1f7	e2e-innovator@test.com	$2b$12$iLabYe//pA7qbIsSkeFDvum7emv9K2Hbjjrh29yJ5OTxZ5mAc43P2	E2E Innovator	\N	innovator	E2E test innovator	["python", "AI"]	["education"]	t	free	\N	t	2026-06-27 23:31:23.934239+00	2026-06-27 23:31:24.035591+00	f	f	\N	\N	f
7f2981f9-195d-4d51-98c5-864bbfb5e98b	e2e-investor@test.com	$2b$12$ZYBkg8aQl75EVG56pAdf2.FIgdJB0F8vwrpiWvr0sHZiks4m/txCu	E2E Investor	\N	innovator	\N	[]	[]	t	free	\N	t	2026-06-27 23:31:24.325649+00	2026-06-27 23:31:24.378617+00	f	f	\N	\N	f
059bc0a7-7ed9-40e1-b0a1-de241da461a5	e2e-innovator2@test.com	$2b$12$31/xcSlPhbT30jSO7Jro7.Xos9Vbm1HmEdX6DPiKDKX2h0s7YTPLq	E2E Innovator 2	\N	innovator	E2E innovator	["AI"]	["education"]	t	free	\N	t	2026-06-27 23:33:32.172124+00	2026-06-27 23:33:32.262859+00	f	f	\N	\N	f
0542816d-c2ce-4a55-9be4-dd530d1bb94b	e2e-investor2@test.com	$2b$12$vMdHdxv8e5UeD9P/l99yQOZtmJm89dieYK5ZTcBcXOeKdt8m/6T1q	E2E Investor 2	\N	innovator	\N	[]	[]	t	free	\N	t	2026-06-27 23:33:32.525243+00	2026-06-27 23:33:32.629263+00	f	f	\N	\N	f
25425973-187a-411d-a306-e0ea2ca1f7ad	e2e-inno-v3@test.com	$2b$12$2/q9kzJ1CJDEEb5LhNzGT.HLCP3bUwIZS69MoIjzkZl9584CvzJKq	Alice Innovator	\N	innovator	Education innovator	["AI", "EdTech"]	["education"]	t	free	\N	t	2026-06-27 23:35:44.083159+00	2026-06-27 23:35:44.169646+00	f	f	\N	\N	f
6fbb9184-d171-4425-9e23-14a6959dc992	e2e-inv-v3@test.com	$2b$12$fUYz4aIuSrQQTV2iCYrzZ.TjZCDuGNVjZ6Yvz.2nRToMafU5w6l8y	Bob Investor	\N	investor	\N	[]	[]	t	free	\N	t	2026-06-27 23:35:44.439246+00	2026-06-27 23:35:44.529156+00	f	f	\N	\N	f
71010be4-dff0-468a-9971-ddb378684531	test@test.com	$2b$12$Kf1LEJ4J/sE/4SakOmD/YuY0mGD4gcvhIyC4pbD0V4UyRtmGpYkCC	Test User	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-28 01:09:56.171429+00	\N	f	f	\N	\N	f
46ec93b5-a462-490a-9d72-02065b706e89	rate1@test.com	$2b$12$qjxd.pp0CtXjuZoHxGcL7eyM5GSthoNTbJGrBa09PPGVOHckGUTRW	Rate User	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-28 01:10:02.393339+00	\N	f	f	\N	\N	f
bc2519a9-472f-4a26-9e91-90a1a0410068	rate2@test.com	$2b$12$tmQ7lRdjnpiK3Eg/Jt5kn.CySYSdKbBqwjktacImrQRCDt0mx7ore	Rate User	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-28 01:10:02.633439+00	\N	f	f	\N	\N	f
20312500-0600-450b-af3b-f26fc42ab6c5	rate3@test.com	$2b$12$oeuaCZAtqVJpQafQlbz1JOaY1M.TtpHInJToble5H3IrEHctJswl6	Rate User	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-28 01:10:02.872755+00	\N	f	f	\N	\N	f
9beaec8b-607f-41e4-969b-33e311282045	rate4@test.com	$2b$12$Ej2IeCIsNSeZ.oAGUI0wN.N.ZhQFfDPReXvxAW0hrZSRy8oBWPREO	Rate User	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-28 01:10:03.111614+00	\N	f	f	\N	\N	f
a30c1f68-275b-47c7-b83d-99654a7c3dfb	c3test@test.com	$2b$12$MhU/9JFYEDKqIW4SYTIoBuwyy1nZtnV2bMVeonT.dP3pFKa.by8k.	C3 Tester	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-29 08:32:06.704401+00	\N	f	f	\N	\N	f
d6940c0a-aac3-401a-915d-ad826d67bc47	verify-c1@test.com	$2b$12$jjMVCRP1n4ZXLY8hzo9iUO0.0BKCgX/XvWYEeoNQDu9Ms0QnVgDl.	C1 Verify	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-29 08:38:21.947205+00	\N	f	f	\N	\N	f
ae8da5fc-8ddd-4287-b575-f3ee748b4b83	admin@solhub.io	$2b$12$FI/AzW10v8FADO8L2WdnyOO.BNsoK5A9js20QG.qLyt/YHYCRmdPe	SOL Admin	\N	admin	\N	[]	[]	t	free	\N	t	2026-06-27 02:33:57.716817+00	2026-06-28 01:30:21.14933+00	t	f	\N	\N	f
3bd46785-7512-499d-a4e1-373e47867c32	verify-c3@test.com	$2b$12$E1vOiguH6/1WzqLLyyfn0eAyB0I51BHxWcSbR8/DD.iQZRW7.mFG6	C3 Verify	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-29 08:38:24.008878+00	\N	f	f	\N	\N	f
dafa46cc-be7a-4d3d-8c8e-b3ddd48a8c70	wstest@test.com	$2b$12$ksfiov0721P4mnIzKlwqXO5oeXOv65r8YrhTaWMnqlyXi7N78LPra	WS Test	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-29 08:39:49.518737+00	\N	f	f	\N	\N	f
a984d505-b73d-4704-94ba-00f73cbc8a5b	fin-c1@test.com	$2b$12$ukAeq3EKqvVKEuE9OFI8puOtgRV61uEc1Pnzg04.6kA/D1/F5GUTe	Final C1	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-29 08:40:01.920955+00	\N	f	f	\N	\N	f
e9c32c35-e210-4a6a-958a-bf47ec48a4b1	fin-test@test.com	$2b$12$GJQftHVpn9fOICI6G0xg5eGMWrXzDWXcBBkcHVggcQ187ssCYHOHq	Final Test	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-29 08:44:07.372485+00	\N	f	f	\N	\N	f
07b3e8e2-74a5-41a0-aac5-4820790747b3	erthtek@protonmail.com	$2b$12$5FlEPz0TO3ZWyHc5zlnyd.08Rb75F9bXUgWfOscq/DCIJgcSbb6BG	Shan Do	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-30 03:24:23.27133+00	\N	f	f	\N	2026-06-30 03:24:23.27069+00	t
4e1d9656-ed17-440a-b877-a3500be65971	she@me.us	$2b$12$0H2HLlA/e7sIceLVWTVWJu.t9Mpnf6vMW4msixIRuREa5nQdO76xu	Shan Dev	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-30 07:22:03.596668+00	\N	f	f	\N	2026-06-30 07:22:03.595998+00	t
18ecec63-47e0-4642-8d23-172b693f3011	you@example.com	$2b$12$C./yvoP4mYBpdyKTBT3lHe49b2/gysfaEWps.8oFawJPvItFkvBs.	dev test	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-30 07:28:10.912572+00	\N	f	f	\N	2026-06-30 07:28:10.911872+00	t
f749b035-d970-443f-a040-9e780cacce5b	me@you.us	$2b$12$68SbOrrIIhAhb9ryaJlpjuMZ35xwiBxv9O2Z1D.0AvhgTOYYIP1YG	larry	\N	innovator	\N	["Systems Development"]	["AgriTech"]	t	free	\N	t	2026-06-30 03:27:01.396901+00	2026-06-30 07:50:06.818689+00	f	f	\N	2026-06-30 03:27:01.396014+00	t
e6930429-7852-4bb5-8c7e-4333dbbeb32d	flowtest@test.com	$2b$12$EpS3OTSZlCZi.aMoZN1UbeP3BpfzjzOyOEk6D.Tkncd61z8VjxWlS	Flow Test User	\N	innovator	\N	[]	[]	f	free	\N	t	2026-06-30 09:47:08.176543+00	\N	f	f	\N	2026-06-30 09:47:08.175793+00	f
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_tokens (id, user_id, token_hash, expires_at, is_used, created_at) FROM stdin;
51bc0f20-6fa4-4f33-8cf8-e0520acd599b	ae8da5fc-8ddd-4287-b575-f3ee748b4b83	dfaacf4fe749876c79500fd0802287034070ad0f9374ba6dd80aaa00b1b4ae0f	2026-06-30 06:16:53.144668+00	f	2026-06-29 06:16:53.145412+00
b5334def-4610-48cc-ac44-f3ad64d5595c	8be76b94-0b77-4126-8844-fca5faf0ff90	d3bf247e32e7ea8cf1425dddb6cfe38b19fc1e9a49be615e7874f40c0e1939f8	2026-06-30 08:31:20.528235+00	f	2026-06-29 08:31:20.530064+00
5bf4690b-c349-4c75-8ba3-19905c77abb8	546d665f-e252-4183-bafc-e0795d12040a	0c9b724b2b084b5f04ef15d054511ab35f13c784d56208b0eea8e4c1e14daed3	2026-06-30 08:32:02.575045+00	f	2026-06-29 08:32:02.580286+00
bda6eaa3-deed-4234-9d63-3f31cc9a8332	a30c1f68-275b-47c7-b83d-99654a7c3dfb	a5fc8b1d66516d7389c215153230d241530fff203494943ff463ad51d720c812	2026-06-30 08:32:06.705397+00	f	2026-06-29 08:32:06.706372+00
7bf83b19-e724-49eb-b0be-d18b86ef68e2	d6940c0a-aac3-401a-915d-ad826d67bc47	86c3d91390f9e1eab7c908a3202c39ebcee7fc39c0e66f73a95c2066a00d34b7	2026-06-30 08:38:21.950262+00	f	2026-06-29 08:38:21.953819+00
e28b1936-21c6-4ed0-aa29-74bfa48d2444	3bd46785-7512-499d-a4e1-373e47867c32	282c0f1af3b2647d90926569804480b82ea8da75d8a93d5f029ee4badaa24507	2026-06-30 08:38:24.009785+00	f	2026-06-29 08:38:24.010659+00
b3c459dd-fb08-4dfc-a28e-e2f7c4f0e6cd	dafa46cc-be7a-4d3d-8c8e-b3ddd48a8c70	58a24f65ab5b80e0c57277fe2ff310e9f041448785d683f6f932557ef7fa231e	2026-06-30 08:39:49.521511+00	f	2026-06-29 08:39:49.524729+00
07adeba7-96ad-4f97-89ec-ab7232035a58	a984d505-b73d-4704-94ba-00f73cbc8a5b	ed6ba3bd365cd433f70649678f16f0be7f48a7e25e1e399546ec82843b2286cf	2026-06-30 08:40:01.921767+00	f	2026-06-29 08:40:01.922549+00
f3254a26-8128-46f5-b754-758d0a82e6de	e9c32c35-e210-4a6a-958a-bf47ec48a4b1	71cd06d010f26557f0aba7e3b8eb3dbe172f9876784a738b888ae8c14f30d398	2026-06-30 08:44:07.375012+00	f	2026-06-29 08:44:07.378566+00
1c10baf8-e818-4e0d-9b10-893aba3d161a	07b3e8e2-74a5-41a0-aac5-4820790747b3	425f2d76af1be112c970c088b5dd9dfe3e314dc2d4360ae9571e79801ea8920b	2026-07-01 03:24:23.272494+00	f	2026-06-30 03:24:23.27344+00
407eec7f-e3b8-4a69-93e9-af07a4a01da2	f749b035-d970-443f-a040-9e780cacce5b	5a5aa32a8250d99f4eb80bd62d94cacac3c7580a5da0f08a083fd0fccecd97ad	2026-07-01 03:27:01.397795+00	f	2026-06-30 03:27:01.398491+00
d3a15d40-8682-4deb-9733-6e4996af0e81	4e1d9656-ed17-440a-b877-a3500be65971	0024e797df91cffcd4fcbf7f647fba2964e9923fb089c343e6d4913b0a619099	2026-07-01 07:22:03.606207+00	f	2026-06-30 07:22:03.607344+00
5548d090-68e9-4337-94dd-b44891de3ab1	18ecec63-47e0-4642-8d23-172b693f3011	a91b110fb91f05ca2c3386a1a639855b8b643daebc1df7ee86b6207f7a0afd3a	2026-07-01 07:28:10.91338+00	f	2026-06-30 07:28:10.922983+00
48affa04-4071-404e-94af-b15976d772a8	e6930429-7852-4bb5-8c7e-4333dbbeb32d	4aeb7dd6b457605571e43cd549de4722d88ffcc3c4bb5819dbab7bdacf72c0ed	2026-07-01 09:47:08.177903+00	f	2026-06-30 09:47:08.186934+00
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_events (id, event_id, event_type, source, payload, created_at) FROM stdin;
\.


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: album_media album_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.album_media
    ADD CONSTRAINT album_media_pkey PRIMARY KEY (id);


--
-- Name: albums albums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: blocks blocks_blocker_id_blocked_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_blocker_id_blocked_id_key UNIQUE (blocker_id, blocked_id);


--
-- Name: blocks blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_pkey PRIMARY KEY (id);


--
-- Name: blog_categories blog_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (id);


--
-- Name: doc_categories doc_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_categories
    ADD CONSTRAINT doc_categories_pkey PRIMARY KEY (id);


--
-- Name: doc_library_items doc_library_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_library_items
    ADD CONSTRAINT doc_library_items_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: event_attendees event_attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: forum_categories forum_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_categories
    ADD CONSTRAINT forum_categories_pkey PRIMARY KEY (id);


--
-- Name: forum_replies forum_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_pkey PRIMARY KEY (id);


--
-- Name: forum_threads forum_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_threads
    ADD CONSTRAINT forum_threads_pkey PRIMARY KEY (id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: group_messages group_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_messages
    ADD CONSTRAINT group_messages_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: investments investments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investments
    ADD CONSTRAINT investments_pkey PRIMARY KEY (id);


--
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: pillar_submissions pillar_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pillar_submissions
    ADD CONSTRAINT pillar_submissions_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_key UNIQUE (user_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_key UNIQUE (user_id);


--
-- Name: connections uq_follower_following; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT uq_follower_following UNIQUE (follower_id, following_id);


--
-- Name: group_members uq_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT uq_group_user UNIQUE (group_id, user_id);


--
-- Name: likes uq_user_post_like; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT uq_user_post_like UNIQUE (user_id, post_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_tokens verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: verification_tokens verification_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: ix_activity_logs_activity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_logs_activity_type ON public.activity_logs USING btree (activity_type);


--
-- Name: ix_activity_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_logs_created_at ON public.activity_logs USING btree (created_at);


--
-- Name: ix_activity_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_logs_user_id ON public.activity_logs USING btree (user_id);


--
-- Name: ix_blocks_blocked_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_blocks_blocked_id ON public.blocks USING btree (blocked_id);


--
-- Name: ix_blocks_blocker_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_blocks_blocker_id ON public.blocks USING btree (blocker_id);


--
-- Name: ix_blog_categories_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_blog_categories_slug ON public.blog_categories USING btree (slug);


--
-- Name: ix_blog_posts_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_blog_posts_slug ON public.blog_posts USING btree (slug);


--
-- Name: ix_doc_categories_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_doc_categories_slug ON public.doc_categories USING btree (slug);


--
-- Name: ix_forum_categories_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_forum_categories_slug ON public.forum_categories USING btree (slug);


--
-- Name: ix_pillar_submissions_pillar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pillar_submissions_pillar ON public.pillar_submissions USING btree (pillar);


--
-- Name: ix_reports_reporter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reports_reporter_id ON public.reports USING btree (reporter_id);


--
-- Name: ix_reports_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reports_status ON public.reports USING btree (status);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_webhook_events_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_webhook_events_event_id ON public.webhook_events USING btree (event_id);


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: album_media album_media_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.album_media
    ADD CONSTRAINT album_media_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id);


--
-- Name: albums albums_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: blocks blocks_blocked_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_blocked_id_fkey FOREIGN KEY (blocked_id) REFERENCES public.users(id);


--
-- Name: blocks blocks_blocker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_blocker_id_fkey FOREIGN KEY (blocker_id) REFERENCES public.users(id);


--
-- Name: blog_posts blog_posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: blog_posts blog_posts_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.blog_categories(id);


--
-- Name: comments comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: comments comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id);


--
-- Name: connections connections_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id);


--
-- Name: connections connections_following_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_following_id_fkey FOREIGN KEY (following_id) REFERENCES public.users(id);


--
-- Name: doc_library_items doc_library_items_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_library_items
    ADD CONSTRAINT doc_library_items_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: doc_library_items doc_library_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_library_items
    ADD CONSTRAINT doc_library_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.doc_categories(id);


--
-- Name: documents documents_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: documents documents_uploader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploader_id_fkey FOREIGN KEY (uploader_id) REFERENCES public.users(id);


--
-- Name: event_attendees event_attendees_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_attendees event_attendees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: events events_organizer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_organizer_id_fkey FOREIGN KEY (organizer_id) REFERENCES public.users(id);


--
-- Name: forum_replies forum_replies_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: forum_replies forum_replies_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.forum_threads(id);


--
-- Name: forum_threads forum_threads_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_threads
    ADD CONSTRAINT forum_threads_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: forum_threads forum_threads_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_threads
    ADD CONSTRAINT forum_threads_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.forum_categories(id);


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: group_members group_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: group_messages group_messages_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_messages
    ADD CONSTRAINT group_messages_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: group_messages group_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_messages
    ADD CONSTRAINT group_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: groups groups_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: investments investments_investor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investments
    ADD CONSTRAINT investments_investor_id_fkey FOREIGN KEY (investor_id) REFERENCES public.users(id);


--
-- Name: investments investments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investments
    ADD CONSTRAINT investments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: likes likes_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id);


--
-- Name: likes likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: matches matches_investor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_investor_id_fkey FOREIGN KEY (investor_id) REFERENCES public.users(id);


--
-- Name: matches matches_mentor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_mentor_id_fkey FOREIGN KEY (mentor_id) REFERENCES public.users(id);


--
-- Name: matches matches_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: messages messages_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: milestones milestones_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pillar_submissions pillar_submissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pillar_submissions
    ADD CONSTRAINT pillar_submissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: posts posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: profiles profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: projects projects_innovator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_innovator_id_fkey FOREIGN KEY (innovator_id) REFERENCES public.users(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: reports reports_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id);


--
-- Name: resources resources_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: verification_tokens verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict DNdXZQUsJootsEgskaHbS6WWKeAjevSuXTWl9GttarajKnh5WBsPZmgXJTbbYHB

